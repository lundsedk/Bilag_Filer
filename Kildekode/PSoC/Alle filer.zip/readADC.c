/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include "readADC.h"


uint16_t *readSensor()
{
    static uint16_t result[4];
    result[0] = readLight();
    result[1] = readHumid();
    result[2] = readWeight();
    result[3] = readWater();
    
    
    return result;
}

uint16_t readLight()
{
    
    // address for light sensor
    Pin_bit0_Write(1);
    Pin_bit1_Write(0);
    Pin_bit2_Write(1);
    
    return readADC();
    
}

uint16_t readHumid()
{
    // address for Humidity sensor
    Pin_bit0_Write(0);
    Pin_bit1_Write(1);
    Pin_bit2_Write(1);
    
    return readADC();
}

uint16_t readWeight()
{
    // address for Weight sensor
    Pin_bit0_Write(0);
    Pin_bit1_Write(1);
    Pin_bit2_Write(0);
    
    return readADC();
}

uint16_t readWater()
{
    // address for Water sensor
    Pin_bit0_Write(0);
    Pin_bit1_Write(0);
    Pin_bit2_Write(0);
    
    return readADC();
}


uint16_t readADC()
{
    uint8_t BUFFER_SIZE = 200;
    uint16_t buffer[BUFFER_SIZE];
    uint32_t count = 0;
    int sum = 0;
    //static char outputBuffer[256];
    
    ADC_DelSig_StartConvert();
    while (count < BUFFER_SIZE)
    {
        if (ADC_DelSig_IsEndConversion(ADC_DelSig_WAIT_FOR_RESULT))
        {
            buffer[count] = ADC_DelSig_GetResult16();
            count++;
        }
    }
    ADC_DelSig_StopConvert();
    for (int i = 0; i<BUFFER_SIZE; i++)
    {
         sum = sum + buffer[i];  
    }
    uint16_t gennemsnit = sum/BUFFER_SIZE;
    
    
    if (gennemsnit > 50000)
        gennemsnit = 0;
    return gennemsnit;
}

void handleByteReceived(uint8_t byteReceived)
{
    switch(byteReceived)
    {
        case 'q' :
        {
            PWM_Start();
            PWM_WriteCompare(255);
        }
        break;
        case 'w' :
        {
            PWM_Stop();
        }
        break;
        default :
        {
            // nothing
        }
        break;
    }
}

/* [] END OF FILE */
