/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include <stdio.h>
#include <math.h>
#include <stdbool.h>

uint16_t *readSensor();
uint16_t readLight();
uint16_t readHumid();
uint16_t readWeight();
uint16_t readWater();
uint16_t readADC();
void handleByteReceived(uint8_t byteReceived);

/* [] END OF FILE */
